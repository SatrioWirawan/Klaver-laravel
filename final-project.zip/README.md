<h1>Final Project</h1>
<h3>Kelompok 9</h3>
<ol>
    <li>Satrio Wirawan</li>
    <li>Yoga Pratama Royaldy </li>
    <li>muhammad habibi ramadhan</li>
</ol>

<h4>Tema Project:</h4>
<p>Online Shop</p>

<h6>ERD</h6>
<img src="https://gitlab.com/SatrioWirawan/final-project/-/raw/main/public/klaver%20ERD.png" alt="" class="" width="">

<h4>Link video</h4>
<p>link deploy : <a href="oeiricky.com"> </a></p>
