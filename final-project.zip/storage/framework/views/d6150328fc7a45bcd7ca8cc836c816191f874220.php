<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
      <h1 class="card-title">Category</h1>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
      <table id="example1" class="table table-bordered table-striped">
        <thead>
        <tr>
          <th>#</th>
          <th>Nama Category</th>
          <th>Deskripsi</th>
          <th>Action</th>
        </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($key + 1); ?></td>
                <td><?php echo e($value->title); ?></td>
                <td><?php echo e($value->content); ?></td>
                <td>
                    <button type="button" id="" class="btn btn-outline-secondary border-1 p-1">
                        <a class="" href="/category/<?php echo e($value->id); ?>" style="color: black;">
                            <span class="far fa-file-alt"></span>
                            show
                        </a>
                    </button>
                    <button type="button" id="" class="btn btn-outline-secondary border-1 p-1">
                        <a class="" href="/category/<?php echo e($value->id); ?>/edit" style="color: black;">
                            <span class="fas fa-edit"></span>
                            Edit
                        </a>
                    </button>
                    <form action="/category/<?php echo e($value->id); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <input type="submit" class="btn btn-danger mr-1" value="Delete">
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="6">No data</td>
            </tr>
            <?php endif; ?>
        </tbody>    
      </table>
      <a href="/category/create" class="btn btn-primary m-2">Add</a>
    </div>
    <!-- /.card-body -->

</div>
<script src="../../plugins/datatables/jquery.dataTables.js"></script>
<script src="../../plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>
<?php $__env->startPush('table-script'); ?>
<script src="<?php echo e(asset('')); ?>plugins/datatables/jquery.dataTables.js"></script>
<script src="<?php echo e(asset('')); ?>plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>
<script>
  $(function () {
    $("#example1").DataTable();
  });
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project\Codingcamp\final-project\resources\views/category.blade.php ENDPATH**/ ?>