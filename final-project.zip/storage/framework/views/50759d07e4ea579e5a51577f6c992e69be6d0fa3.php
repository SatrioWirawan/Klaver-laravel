<?php $__env->startSection('title'); ?>
    | Our Product
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<main id="collections">
    <div class="main container-fluid">
        <div class="px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center">
            <h2 class="display-6">All Product</h2>
        </div>
        <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-6 m-auto">
            <div class="mcontainer">
                <a href="/product/<?php echo e($value->id); ?>">
                    <img src="<?php echo e(asset("")); ?>assets/images/Gallery/<?php echo e($value->title); ?>/1.JPG" alt="Abstract" class="image oversize" width="600">
                    <div class="middle">
                        <div class="text"><?php echo e($value->title); ?></div>
                    </div>
                </a>
            </div>   
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project\Codingcamp\final-project\resources\views/product.blade.php ENDPATH**/ ?>