<?php $__env->startSection('content'); ?>
<div class="card m-2">
    <div class="m-2">
        <h2>Show Category <?php echo e($post->id); ?></h2>
        <hr>
        <h4>Category: <?php echo e($post->title); ?></h4>
        <p>Deskripsi: <?php echo e($post->content); ?></p>
    </div> 
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project\Codingcamp\final-project\resources\views/category/show.blade.php ENDPATH**/ ?>