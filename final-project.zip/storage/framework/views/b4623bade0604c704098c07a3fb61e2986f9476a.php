<?php $__env->startSection('content'); ?>
<a href="/cast/create" class="btn btn-primary m-2">Tambah</a>
        <table class="table">
            <thead class="thead-light">
              <tr>
                <th scope="col">#</th>
                <th scope="col">Nama</th>
                <th scope="col">Umur</th>
                <th scope="col">Bio</th>
                <th scope="col">Action</th>
              </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($key + 1); ?></th>
                        <td><?php echo e($value->nama); ?></td>
                        <td><?php echo e($value->umur); ?></td>
                        <td><?php echo e($value->bio); ?></td>
                        <td class="row">
                            <a href="/cast/<?php echo e($value->id); ?>" class="btn btn-info mr-1">Show</a>
                            <a href="/cast/<?php echo e($value->id); ?>/edit" class="btn btn-primary mr-1">Edit</a>
                            <form action="/cast/<?php echo e($value->id); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <input type="submit" class="btn btn-danger mr-1" value="Delete">
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr colspan="3">
                        <td>No data</td>
                    </tr>  
                <?php endif; ?>              
            </tbody>
        </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project\Codingcamp\final-project\resources\views/admin/index.blade.php ENDPATH**/ ?>