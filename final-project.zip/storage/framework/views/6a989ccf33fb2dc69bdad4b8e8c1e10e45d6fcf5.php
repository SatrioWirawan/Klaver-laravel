<?php $__env->startSection('content'); ?>
<div class="card m-2">
    <div class="m-2">
        <h2>Show Cast <?php echo e($post->id); ?></h2>
        <hr>
        <h4>Nama Product: <?php echo e($post->title); ?></h4>
        <p>Deskripsi: <?php echo e($post->deskripsi); ?></p>
        <p>Foto: <?php echo e($post->foto); ?></p>
        <p>Harga: Rp.<?php echo e($post->harga); ?></p>
    </div> 
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project\Codingcamp\final-project\resources\views/admin/show.blade.php ENDPATH**/ ?>